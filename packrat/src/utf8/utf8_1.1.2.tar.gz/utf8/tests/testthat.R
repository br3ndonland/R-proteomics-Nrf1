library(testthat)
library(utf8)

test_check("utf8")
