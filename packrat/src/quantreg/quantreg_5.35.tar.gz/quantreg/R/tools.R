"FAQ" <- function(pkg = "quantreg")
     file.show(file.path(system.file(package = pkg),"FAQ"))
"ChangeLog" <- function(pkg = "quantreg")
     file.show(file.path(system.file(package = pkg),"ChangeLog"))
