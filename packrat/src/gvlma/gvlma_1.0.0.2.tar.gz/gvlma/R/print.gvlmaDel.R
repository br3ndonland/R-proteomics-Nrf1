"print.gvlmaDel" <-
function(x, ...)
{
  summary.gvlmaDel(x, allstats = FALSE)
}

